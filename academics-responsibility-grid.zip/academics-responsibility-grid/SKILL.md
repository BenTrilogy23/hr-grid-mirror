---
name: academics-responsibility-grid
description: >-
  Answers "who is responsible for / who owns / who do I talk to about" a given
  subject at a given grade level on the Academics team, plus who the two DRI
  Heads are. Use this skill whenever someone asks who owns, leads, is
  responsible for, or is the point of contact for a subject (Math, Reading,
  Language, Writing, Vocabulary, Science, Social Studies) at any grade band
  (PK-3, 4-12, AP, SAT, ISEE/SSAT), or asks who the Learning Science or
  Academics owner of something is, or who the Coaching DRI Head or Campus DRI
  Head is. Trigger this even when the person doesn't say "grid" or "skill" —
  e.g. "who handles AP math?", "who should I ask about middle-school science?",
  "who runs reading for the little kids?", "who's the campus DRI?". Always
  consult this skill rather than guessing from memory, because the owners
  change and the data must be read live.
---

# Academics Responsibility Grid

This skill answers who is responsible for academic learning outcomes across
subjects and grade levels, and who the two DRI Heads are. It works in two
runtimes, and gets its data differently in each (see Step 1). The parsing and
answering rules (Steps 2 onward) are identical either way.

## The two teams (context for framing every answer)

Every subject/grade cell has **two owners, one from each team**:

- **Learning Science** — writes the "second brain": the guidance on how we
  should best serve students in that subject. The *design / approach* role.
- **Academics** — executes on that guidance by building the actual courses and
  content. The *build / delivery* role.

Always name both owners and label which team each belongs to.

## Step 1 — Get the data (prefer live, fall back to snapshot)

**Path 1 — Live, via a shell (Claude Code or any runtime with a working
networked shell).** If you can run shell commands with internet access, fetch
the current grid with `curl`. This is the source of truth — prefer it whenever
the shell works. Try in order and use the first that returns CSV:

```bash
curl -sL "https://docs.google.com/spreadsheets/d/e/2PACX-1vT7ponkOlbS12YNgylFXSGCezfviD6AGBHE6xe2cIm5V9yxWh4EwklF4bsXykr4-0Cz9OinHO27rU72/pub?gid=0&single=true&output=csv"
curl -sL "https://raw.githubusercontent.com/BenTrilogy23/hr-grid-mirror/refs/heads/main/hr-grid.csv"
```

(`curl` is not subject to the web-fetch tool's restrictions, so this works in a
normal shell. The first URL is the live Google Sheet; the second is a daily
mirror kept as a fallback.)

**Path 2 — Embedded snapshot (the Claude.ai app, or any time the shell has no
network).** Do **not** try the web-fetch tool here — it will be blocked. Use the
snapshot below. When you answer from it, add a short note: the data is a
snapshot dated 2026-07-14 and may be out of date, and the live sheet is the
source of truth.

Snapshot (same CSV format as the live source):

```csv
HR grid - Academics,,PK-3 (ELA PK-2),4-12 (ELA 3-12),AP,SAT,ISEE/SSAT
Math,,Zach,John,John,John,John
,,Janna,,Ruchi,Ruchi,Ruchi
Reading,Fiorella Mendez - ELA coordinator,Megan,Sarah,Carl,Carl,Carl
,,Ilma,,Ilma,Ilma,Ilma
Language,,Jen,Jen,N/A,N/A,N/A
,,Peter,,N/A,N/A,N/A
Writing,,Jen,Jen,N/A,N/A,N/A
,,Noel,,N/A,N/A,N/A
Vocabulary,,Megan,Mark,N/A,Carl,Carl
,,Barbara,,N/A,Lucia,
Science,,Zach,Becky,Becky,N/A,N/A
,,James (new starter)/DavidB,,Gary,N/A,N/A
Social Studies: Histories,,Zach,Toby,Toby,N/A,N/A
,,Bill,,Bill,N/A,N/A
Social Studies: Geogs,,Zach,Mark,Mark,N/A,N/A
,,Bill,,Bill,N/A,N/A
Social Studies: Civics/pols,,Zach,Laura,Laura,N/A,N/A
,,Bill,,Bill,N/A,N/A
Social Studies: Econ/bus,,Zach,Becky,Becky,N/A,N/A
,,Bill,,Bill,N/A,N/A
Coaching DRI Head,Diane,,,,,
Campus DRI Head,Bruna,,,,,
```

**Refreshing the snapshot:** re-export the current sheet and replace the block
above, then re-share the skill. Since shared skills auto-push updates to
recipients, everyone picks up the new snapshot. Claude Code users always get
live data regardless, so this refresh mainly serves the Claude.ai audience.

## Step 2 — CSV layout

| Col | Meaning |
|-----|---------|
| A | Subject name (only on the first row of each subject) |
| B | Occasional coordinator note (usually blank) |
| C | Grade band **PK-3** — but **PK-2** for ELA subjects (see note below) |
| D | Grade band **4-12** — but **3-12** for ELA subjects |
| E | **AP** (Advanced Placement) |
| F | **SAT** |
| G | **ISEE/SSAT** (independent-school entrance exams) |

AP, SAT and ISEE/SSAT are test-prep tracks, not ordinary grade levels.

**ELA grade-band shift (important).** The first two columns are labeled PK-3 and
4-12, but for **ELA subjects — Reading, Language, Writing, Vocabulary** — they
actually mean **PK-2** and **3-12** (this is spelled out in the header). So the
split between the two columns falls in a different place for ELA: **grade 3** is
in the *first* column for Math/Science/Social Studies, but in the *second*
column for ELA subjects. Mind this whenever a question names a specific grade
near that boundary.

**Each subject spans two rows:** the **top row** = the **Learning Science**
owner per grade band; the **bottom row** = the **Academics** owner per grade
band. Subjects, in order: Math, Reading, Language, Writing, Vocabulary, Science,
and four Social Studies strands — Histories, Geographies (Geogs),
Civics/Politics (Civics/pols), and Econ/Business (Econ/bus).

### Reading the cells

- **`N/A`** = the subject isn't offered at that grade band. Say so plainly.
- **Blank Academics (bottom-row) 4-12 cell:** the Academics row always leaves
  4-12 blank because that cell is merged with PK-3 in the source. **The PK-3
  Academics owner also covers 4-12** — report them for both. (Confirmed, not a
  guess.)
- **Parenthetical notes carry meaning — preserve them:** `James (new
  starter)/DavidB` = shared/transitioning owners; a form like `X (from Aug: Y)`
  (a handover) can appear when a role is changing hands — report both names and
  the timing rather than flattening to one.
- **Column B coordinator note** (e.g. Reading's "Fiorella Mendez – ELA
  coordinator"): mention it when answering about that subject.

## Step 3 — The two DRI Heads

Read these from the rows near the bottom labeled `Coaching DRI Head` and
`Campus DRI Head` (the name is in column B). Report the live/snapshot values —
currently Coaching = Diane, Campus = Bruna.

## Step 4 — Match the question to the grid

Normalize grade phrasing: "pre-K / kindergarten / K / grades 1-3 / the little
kids / elementary" → **PK-3**; "grades 4-12 / middle school / high school /
older students" → **4-12**; "AP" → **AP**; "SAT prep" → **SAT**; "ISEE / SSAT /
entrance exams" → **ISEE/SSAT**.

**For ELA subjects (Reading, Language, Writing, Vocabulary), shift the
boundary:** the first column covers PK-2 and the second covers 3-12. So a
question about **grade 3** in an ELA subject maps to the *second* column, not
the first (e.g. "Reading for a 3rd grader" → the 3-12 column → Sarah / Ilma,
not the PK-2 column). For all other subjects, grade 3 stays in the first column.

Match subjects flexibly: "history" → Histories; "geography" → Geogs;
"civics / government / politics" → Civics/pols; "economics / business" →
Econ/bus; "spelling / vocab" → Vocabulary. If the subject or grade band is
ambiguous, ask one brief clarifying question first.

## Step 5 — Answer format

Give both owners, labeled by team, e.g.:

> **Math — AP**
> - Learning Science (designs the approach): John
> - Academics (builds the content): Ruchi

Add any relevant note (handover, shared owner, coordinator, the inherited 4-12
Academics owner, or — on Claude.ai — the snapshot-date caveat). If the cell is
`N/A`, say the subject isn't offered at that level. For a whole subject across
grades, or a whole grade band across subjects, use a short table. Keep answers
concise and factual — this is a directory lookup, not analysis.

## Troubleshooting

- **Claude Code, live fetch fails** (network blip, or `curl` blocked by a
  managed-egress / Cowork sandbox): fall back to the embedded snapshot and tell
  the user you used snapshot data because the live source was unreachable. On a
  standard laptop this is rare; on a restricted network, `docs.google.com` and
  `raw.githubusercontent.com` may need to be on the approved-domains list.
- **Claude.ai:** the embedded snapshot is expected and always works — no fetch
  needed. Don't attempt the web-fetch tool; it's blocked by a provenance rule
  for URLs that only appear inside the skill.
- **Either runtime:** never invent a name. If you somehow have neither live data
  nor the snapshot, say you can't reach the grid rather than guessing.
